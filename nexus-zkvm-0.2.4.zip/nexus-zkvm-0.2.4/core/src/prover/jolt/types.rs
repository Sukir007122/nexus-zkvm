//! Default types and traits for use by zkVM + Jolt pipeline

pub use nexus_jolt::{JoltCommitments, JoltPreprocessing, JoltProof, F, PCS};
