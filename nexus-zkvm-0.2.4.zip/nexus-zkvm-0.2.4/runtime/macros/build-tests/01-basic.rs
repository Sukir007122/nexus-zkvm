mod test1 {
    #[nexus_rt_macros::main]
    fn main() {}
}

mod test2 {
    #[nexus_rt_macros::main]
    pub fn main() {}
}

fn main() {}
