# Nexus Docs

Tailwind CSS uses [Next.js](https://nextjs.org/) and [Nextra](https://nextra.site/) for its documentation.

To run the project locally, first install the dependencies:

```bash
npm install
```

Next, run the development server:

```bash
npm run dev
```
