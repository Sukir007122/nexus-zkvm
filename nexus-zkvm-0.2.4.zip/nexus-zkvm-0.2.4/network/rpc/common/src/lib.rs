pub mod ark_serde;
pub mod hash;

pub type ElfBytes = Vec<u8>;
pub use ark_serde::ArkWrapper;
