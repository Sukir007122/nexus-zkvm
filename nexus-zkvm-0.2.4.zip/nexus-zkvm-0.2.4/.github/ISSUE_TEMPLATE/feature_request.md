---
name: Feature request
about: Suggest new features for the zkVM
title: '[FEATURE]: '
labels: ['feature request']
---

### What is the problem?
Answer here...

### What do you want to happen?
Answer here...

### Existing alternatives
What, if any, alternative solutions or features have you considered?

### Additional notes
Add any other context or screenshots about the feature request can go here.
