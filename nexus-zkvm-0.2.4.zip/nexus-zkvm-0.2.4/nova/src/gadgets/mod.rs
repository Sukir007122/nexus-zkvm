pub(crate) mod cyclefold;
pub(crate) mod emulated;
