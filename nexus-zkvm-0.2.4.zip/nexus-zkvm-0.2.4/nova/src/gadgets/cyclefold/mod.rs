pub(crate) mod hypernova;
pub(crate) mod nova;
pub(crate) mod secondary;
