pub mod hypernova;
pub mod nova;
pub mod supernova;
