/// Sequential (non-parallelized, non-distributed) proving for [HyperNova](https://eprint.iacr.org/2023/573).
pub mod seq;
