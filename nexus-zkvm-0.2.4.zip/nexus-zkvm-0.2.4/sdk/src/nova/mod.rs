/// Sequential (non-parallelized, non-distributed) proving for [Nova](https://eprint.iacr.org/2021/370).
pub mod seq;
